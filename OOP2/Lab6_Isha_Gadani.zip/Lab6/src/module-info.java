/**
 * 
 */
/**
 * @author ISHA
 *
 */
module Lab6 {
}