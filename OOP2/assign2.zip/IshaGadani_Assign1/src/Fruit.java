import java.util.Scanner;

class Fruit extends FoodItem {
    protected int jarSize;

    public boolean addItem(Scanner scanner) {
        System.out.println("Enter the code for the item: ");
        if (inputCode(scanner, false)) {
            System.out.println("Enter the name for the item: ");
            itemName = scanner.nextLine();

            System.out.println("Enter the quantity for the item: ");
            if (scanner.hasNextInt()) {
                itemQuantityInStock = scanner.nextInt();
                scanner.nextLine(); // Consume newline
            } else {
                System.out.println("Invalid quantity...");
                return false;
            }

            System.out.println("Enter the cost of the item: ");
            if (scanner.hasNextFloat()) {
                itemCost = scanner.nextFloat();
                scanner.nextLine(); // Consume newline
            } else {
                System.out.println("Invalid cost...");
                return false;
            }

            System.out.println("Enter the sales price of the item: ");
            if (scanner.hasNextFloat()) {
                itemPrice = scanner.nextFloat();
                scanner.nextLine(); // Consume newline
            } else {
                System.out.println("Invalid sales price...");
                return false;
            }

            System.out.println("Enter the size of the jar in millilitres: ");
            if (scanner.hasNextInt()) {
                jarSize = scanner.nextInt();
                scanner.nextLine(); // Consume newline
            } else {
                System.out.println("Invalid jar size...");
                return false;
            }

            return true; // Successfully added item
        } else {
            System.out.println("Invalid code...");
            return false;
        }
    }
}