package Factory;

public interface Shape {
	public double calculateVolume();
}
